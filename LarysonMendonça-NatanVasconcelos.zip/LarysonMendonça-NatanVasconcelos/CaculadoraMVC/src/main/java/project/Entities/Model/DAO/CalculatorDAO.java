/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package project.Entities.Model.DAO;

/**
 *
 * @author Laryson Martins <larysonmartins008@gmail.com>
 */

import java.io.FileWriter;
import java.io.IOException;
import project.Entities.Model.VO.CalculatorVO;
 
/* Classe responsavel pelo o banco de dados */

public class CalculatorDAO {
    private static final String FILE_PATH = "HistoricoCalculadora.csv";

    public void SalvarHistorico(CalculatorVO calculatorVO) {
        try (FileWriter writer = new FileWriter(FILE_PATH, true)) { // true para append no arquivo
            for (String entry : calculatorVO.getHistory()) {
                writer.write(entry + "\n");
            }
            calculatorVO.getHistory().clear(); // Limpa o histórico após salvar
        } catch (IOException e) {
            System.err.println("Erro ao salvar histórico: " + e.getMessage());
        }
    }
}
 