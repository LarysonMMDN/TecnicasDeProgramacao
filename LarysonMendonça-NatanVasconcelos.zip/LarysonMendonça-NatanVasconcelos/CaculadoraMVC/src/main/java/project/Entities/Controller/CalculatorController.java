/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package project.Entities.Controller;

/**
 *
 * @author Laryson Martins <larysonmartins008@gmail.com>
 */

import project.Entities.Model.BO.CalculatorBO;
import project.Entities.Model.DAO.CalculatorDAO;
import project.Entities.Model.VO.CalculatorVO;
import project.Entities.View.View;

/**
 * A classe CalculatorController serve como o controlador na arquitetura MVC (Model-View-Controller) de uma calculadora.
 * Ela é responsável por receber eventos da interface do usuário (View), processar os dados através das operações lógicas
 * (CalculatorBO) e atualizar a interface com os resultados.
 */
public class CalculatorController {

    // Instâncias dos componentes principais do MVC: lógica de negócios, objetos de valor, persistência e visualização
    private CalculatorBO calculatorBO;
    private CalculatorVO calculatorVO;
    private CalculatorDAO calculatorDAO;
    private View view;

    /**
     * Construtor da classe CalculatorController.
     * Inicializa os componentes BO (Business Object), VO (Value Object), DAO (Data Access Object) e View.
     * Estabelece a conexão entre a View e o Controller.
     *
     * A interface de visualização, que representa a camada de apresentação para o usuário.
     */
    public CalculatorController(View view) {
        this.view = view;
        this.calculatorVO = new CalculatorVO();
        this.calculatorBO = new CalculatorBO(calculatorVO);
        this.calculatorDAO = new CalculatorDAO();
        
        view.setController(this); // Conecta a View ao Controller
    }

    /**
     * Manipula os eventos de clique nos botões da interface.
     * Processa a entrada com base no rótulo do botão e executa a operação correspondente.
     * 
     * O rótulo do botão clicado (ex.: "+", "-", "C", "=", "x²", etc.).
     */
    public void ButtonClick(String label) {
        try {
            switch (label) {
                case "C":
                    // Limpa o display e o estado atual da calculadora
                    calculatorVO.limparInput();
                    calculatorVO.setResult(0);
                    calculatorVO.setLastOperator("");
                    view.updateDisplay("0");
                    break;
                
                case "=":
                    // Executa a operação acumulada e exibe o resultado final
                    calculatorBO.performOperation("");
                    view.updateDisplay(String.valueOf(calculatorVO.getResult()));
                    calculatorVO.setLastOperator("");

                    // Salva o histórico do cálculo em um arquivo CSV
                    calculatorDAO.SalvarHistorico(calculatorVO);
                    break;

                case "+":
                case "-":
                case "x":
                case "÷":
                    // Realiza a operação aritmética com o operador especificado
                    calculatorBO.performOperation(label);
                    break;

                case "%":
                    // Calcula a porcentagem do valor atual e exibe o resultado
                    calculatorBO.calculoPorcentagem();
                    view.updateDisplay(String.valueOf(calculatorVO.getResult()));
                    calculatorDAO.SalvarHistorico(calculatorVO);
                    break;

                case "x²":
                    // Calcula o quadrado do valor atual e exibe o resultado
                    calculatorBO.calculoQuadrado();
                    view.updateDisplay(String.valueOf(calculatorVO.getResult()));
                    calculatorDAO.SalvarHistorico(calculatorVO);
                    break;

                case "√":
                    // Calcula a raiz quadrada do valor atual e exibe o resultado
                    calculatorBO.calculoRaizQuadrada();
                    view.updateDisplay(String.valueOf(calculatorVO.getResult()));
                    calculatorDAO.SalvarHistorico(calculatorVO);
                    break;

                default:
                    // Adiciona números ou ponto decimal ao valor de entrada atual e exibe o valor atualizado
                    calculatorVO.getCurrentInput().append(label);
                    view.updateDisplay(calculatorVO.getCurrentInput().toString());
                    break;
            }
        } catch (ArithmeticException e) {
            // Em caso de erro aritmético, exibe uma mensagem de erro na interface
            view.updateDisplay("Erro");
        }
    }
}
