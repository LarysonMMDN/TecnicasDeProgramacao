/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package project.Entities.Model.VO;

/**
 *
 * @author Laryson Martins <larysonmartins008@gmail.com>
 */

import java.util.ArrayList;
import java.util.List;

/* Essa classe será responsável por armazenar os dados
da calculadora, como o valor atual, 
o operador, e o resultado. */

public class CalculatorVO {
    private float result;
    private String lastOperator;
    private StringBuilder currentInput;
    private List<String> history;

    public CalculatorVO() {
        this.result = 0;
        this.lastOperator = "";
        this.currentInput = new StringBuilder();
        this.history = new ArrayList<>();
    }

    public float getResult() {
        return result;
    }

    public void setResult(float result) {
        this.result = result;
    }

    public String getLastOperator() {
        return lastOperator;
    }

    public void setLastOperator(String lastOperator) {
        this.lastOperator = lastOperator;
    }

    public StringBuilder getCurrentInput() {
        return currentInput;
    }

    public void limparInput() {
        this.currentInput.setLength(0);
    }

    public List<String> getHistory() {
        return history;
    }

    public void addHistory(String entry) {
        if (entry.contains("+") || entry.contains("-") || entry.contains("x")) {
            history.add(entry);
        }
    }
}
