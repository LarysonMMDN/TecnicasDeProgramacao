/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * 
*/

package project.Entities.Model.BO; 

/**
 * 
 * @autor Laryson Martins <larysonmartins008@gmail.com>
 * 
*/

/*Classe de lógica de negócios para operações de calculadora. */

// Importando a classe CalculatorVO que tem os dados da calculadora.
import project.Entities.Model.VO.CalculatorVO; 

public class CalculatorBO {
    // Variável privada para armazenar o objeto CalculatorVO.
    private CalculatorVO calculatorVO; 

    // Construtor que recebe um CalculatorVO e o armazena na variável privada calculatorVO.
    public CalculatorBO(CalculatorVO calculatorVO) {
        this.calculatorVO = calculatorVO;
    }

    // Método que executa operações básicas (+, -, x, ÷) com base no operador passado como argumento.
    public void performOperation(String operator) {
        // Converte o input atual para float ou usa 0 se o input estiver vazio.
        float inputNumber = calculatorVO.getCurrentInput().length() > 0 ? 
        Float.parseFloat(calculatorVO.getCurrentInput().toString()) : 0;
        float previousResult = calculatorVO.getResult(); // Armazena o resultado anterior para o histórico.

        // Switch para verificar o último operador e executar a operação correspondente.
        switch (calculatorVO.getLastOperator()) {
            case "+":
                // Soma
                calculatorVO.setResult(calculatorVO.getResult() + inputNumber); 
                break;
            case "-":
                // Subtração
                calculatorVO.setResult(calculatorVO.getResult() - inputNumber); 
                break;
            case "x":
                // Multiplicação
                calculatorVO.setResult(calculatorVO.getResult() * inputNumber); 
                break;
            case "÷":
                // Divisão
                if (inputNumber != 0) { // Verifica se o divisor não é zero.
                    calculatorVO.setResult(calculatorVO.getResult() / inputNumber); 
                } else {
                    calculatorVO.limparInput(); // Limpa o input
                    throw new ArithmeticException("Erro: Divisão por zero"); // Mostra uma exceção em caso de divisão por zero.
                }
                break;
            default:
                // Define o resultado como o input atual se não ter operador.
                calculatorVO.setResult(inputNumber); 
                break;
        }

        // Se o último operador não for espaço vazio, adiciona a operação ao histórico.
        if (!calculatorVO.getLastOperator().equals(" ")) {
            String entry = previousResult + " " + calculatorVO.getLastOperator() + " " + inputNumber + " = " + calculatorVO.getResult();
            // Adiciona a operação no histórico da calculadora.
            calculatorVO.addHistory(entry); 
        }
        // Limpa p painel de Exibição após a operação.
        calculatorVO.limparInput(); 
        // Atualiza o último operador para o novo.
        calculatorVO.setLastOperator(operator); 
    }

    // Método para calcular o quadrado do número no input.
    public void calculoQuadrado() {
        // Converte o input para float.
        float inputNumber = Float.parseFloat(calculatorVO.getCurrentInput().toString()); 
        // Calcula o quadrado.
        calculatorVO.setResult(inputNumber * inputNumber); 

        // Adiciona o cálculo ao histórico.
        calculatorVO.addHistory(inputNumber + "² = " + calculatorVO.getResult()); 
        // Limpa o input após a operação.
        calculatorVO.limparInput(); 
    }

    // Método para calcular a raiz quadrada do número no input.
    public void calculoRaizQuadrada() {
        float inputNumber = Float.parseFloat(calculatorVO.getCurrentInput().toString()); // Converte o input para float.
        if (inputNumber >= 0) { // Verifica se o número é não negativo.
            calculatorVO.setResult((float) Math.sqrt(inputNumber)); // Calcula a raiz quadrada.
            calculatorVO.addHistory("√" + inputNumber + " = " + calculatorVO.getResult()); // Adiciona o cálculo ao histórico.
        } else {
            throw new ArithmeticException("Erro: Raiz quadrada de número negativo"); // Lança exceção para raiz negativa.
        }
        calculatorVO.limparInput(); // Limpa o input após a operação.
    }

    // Método para calcular a porcentagem do número no input.
    public void calculoPorcentagem() {
        float inputNumber = Float.parseFloat(calculatorVO.getCurrentInput().toString()); // Converte o input para float.
        calculatorVO.setResult(inputNumber / 100); // Calcula a porcentagem.

        calculatorVO.addHistory(inputNumber + "% = " + calculatorVO.getResult()); // Adiciona o cálculo ao histórico.
        calculatorVO.limparInput(); // Limpa o input após a operação.
    }
}
