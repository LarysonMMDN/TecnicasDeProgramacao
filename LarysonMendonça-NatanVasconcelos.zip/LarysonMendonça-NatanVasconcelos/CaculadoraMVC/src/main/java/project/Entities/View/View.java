/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package project.Entities.View;

/**
 *
 * @author Laryson Martins <larysonmartins008@gmail.com>
 */

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import project.Entities.Controller.CalculatorController;

public class View extends JFrame {

    private int posiçãoButonX;
    private int posiçãoButonY;
    private JLabel displayLabel;
    private JButton button;
    private Font FonteGeral;
    private CalculatorController controller;

    public View(String Nome) {

        // Configurações do Frame Principal
        setTitle(Nome);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(335, 540);
        setResizable(false);
        setLocationRelativeTo(null);
        setLayout(null);
        try {
            ImageIcon icon = new ImageIcon(getClass().getResource("Resource/Icon.png"));
            setIconImage(icon.getImage());
        } catch (NullPointerException e){
            System.out.println("Erro");
        }
        
        // Painel Principal
        JPanel PainelPrincipal = new JPanel();
        PainelPrincipal.setBounds(0, 0, 335, 540);
        PainelPrincipal.setBackground(new Color(130, 130, 130));
        PainelPrincipal.setLayout(null);

        // Painel de exibição dos números
        JPanel ExibiçãoNum = new JPanel();
        ExibiçãoNum.setBounds(10, 10, 300, 90);
        ExibiçãoNum.setBackground(new Color(130, 130, 130));
        ExibiçãoNum.setLayout(new BorderLayout());

        // Label para exibir números e resultados
        FonteGeral = new Font("Segoe UI", Font.BOLD, 25);
        // Dentro do construtor da classe View, após a criação do displayLabel
        displayLabel = new JLabel("0", SwingConstants.RIGHT) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2d = (Graphics2D) g.create();
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        
                // Desenha um retângulo arredondado para o fundo
                g2d.setColor(new Color(217, 217, 217)); // Define a cor do fundo arredondado
                g2d.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20); // Define o fundo arredondado
        
                // Chama o método paintComponent da superclasse para desenhar o texto
                super.paintComponent(g2d);
                g2d.dispose();
            }
        
            @Override
            public void paintBorder(Graphics g) {
                // Não desenha borda externa
            }
        };
        
        displayLabel.setFont(FonteGeral);
        displayLabel.setForeground(Color.BLACK);
        displayLabel.setHorizontalAlignment(SwingConstants.RIGHT);
        displayLabel.setOpaque(false); // Mantém o fundo transparente
        displayLabel.setBorder(new EmptyBorder(0, 0, 0, 30)); // Adiciona margem direita
        ExibiçãoNum.add(displayLabel, BorderLayout.CENTER);
        PainelPrincipal.add(ExibiçãoNum, BorderLayout.CENTER);

        // Adicionar botões e configurar suas funções
        adicionarBotoes(PainelPrincipal);

        // Adicionando o painel principal ao frame
        add(PainelPrincipal);
        setVisible(true);
    }

    // Função para adicionar os botões e configurar suas funções
    private void adicionarBotoes(JPanel PainelPrincipal) {
        String[] buttonLabels = {
            "%", "x²", "√", "÷", 
            "7", "8", "9", "x",
            "4", "5", "6", "+",
            "1", "2", "3", "-",
            "C", "0", ".", "="
        };

        posiçãoButonX = 17;
        posiçãoButonY = 110;

        for (String label : buttonLabels) {
            button = BotaoPersonalizado(label, posiçãoButonX, posiçãoButonY, 
            60, 60, 20, FonteGeral, 
            new Color(0,0,0), new Color(232, 105, 14), new Color(217, 217, 217)
            );
            button.addActionListener(new ButtonClickListener(label));
            PainelPrincipal.add(button);

            posiçãoButonX += 75;
            if (posiçãoButonX > 260) {
                posiçãoButonX = 17;
                posiçãoButonY += 75;
            }
        }
    }

        // Configura o controlador
        public void setController(CalculatorController controller) {
            this.controller = controller;
        }

        // Atualiza o display com novos valores
        public void updateDisplay(String text) {
            displayLabel.setText(text);
        }

        // Adicionar evento para chamar o controller ao clicar nos botões
        private class ButtonClickListener implements ActionListener {
            private String label;

            public ButtonClickListener(String label) {
                this.label = label;
            }

            @Override
            public void actionPerformed(ActionEvent e) {
                controller.ButtonClick(label); // Adiciona a função para o botão
            }
        }

    // Botão Personalizado
    private JButton BotaoPersonalizado(String nome, int posX, int posY, int largura, int altura, int curvaturaBorda, Font fonte, Color corTexto, Color corOperações, Color corNumeros) {
        JButton botao = new JButton(nome) {
            @Override // Alterando um metodo para pintar o botão
            protected void paintComponent(Graphics g) {
                Graphics2D G2D = (Graphics2D) g.create();
                G2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                
                String[] buttonOperações = {
                    "%", "x²", "√", "÷", "x",
                    "+", "-", "C", ".", "="
                };
                
                String[] buttonNumeros = {
                    "7", "8", "9", 
                    "4", "5", "6", 
                    "1", "2", "3",
                    "0",
                };
                // Colocar cor nos botões de operações
                for (String operação : buttonOperações) {
                    if (operação.equals(nome)) {
                        G2D.setColor(corOperações);
                    }
                }
                // Colocar cor nos botões de operações
                for (String numeros : buttonNumeros) {
                    if (numeros.equals(nome)) {
                        G2D.setColor(corNumeros);
                    }
                }
                
                // Cor do fundo
                G2D.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20); // Ajuste os valores para a curvatura

                super.paintComponent(G2D);
                G2D.dispose();
            }

            @Override
            public void setBorder(Border border) {
                // Override para evitar qualquer borda padrão
            }
        };
        botao.setBounds(posX, posY, largura, altura);
        botao.setFont(fonte);
        botao.setForeground(corTexto);
        
        
        // Estilo do botão para a curvatura das bordas
        botao.setBorder(BorderFactory.createLineBorder(corTexto, curvaturaBorda));
        botao.setContentAreaFilled(false);
        botao.setOpaque(false);
    
        // Configura o estilo arredondado das bordas
        botao.setBorder(new javax.swing.border.AbstractBorder() {
            @Override
            public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
                Graphics2D g2d = (Graphics2D) g;
                g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2d.setColor(corTexto);
                g2d.drawRoundRect(x, y, width - 1, height - 1, curvaturaBorda, curvaturaBorda);
            }
        });

        return botao;
    }
    
}
