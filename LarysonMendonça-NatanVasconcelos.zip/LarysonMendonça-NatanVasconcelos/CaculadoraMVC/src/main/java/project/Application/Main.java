/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package project.Application;

/**
 *
 * @author Laryson Martins <larysonmartins008@gmail.com>
 */


import project.Entities.Controller.CalculatorController;
import project.Entities.View.View;

public class Main {
    public static void main(String[] args) {
        // Cria a interface de visualização
        View view = new View("Calculator");

        // Cria o controlador e conecta a visualização
        CalculatorController controller = new CalculatorController(view);
    }
}